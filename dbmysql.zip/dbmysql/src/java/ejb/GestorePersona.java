/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entita.Persona;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author mauro
 */
@Stateless
public class GestorePersona {
    @PersistenceContext(unitName = "dbmysqlPU")
    private EntityManager em;

    public void persist(Persona persona) {
        em.persist(persona);
    }
public List<Persona> getListaPersone(){
List<Persona> listaPersona=em.createQuery("select p from Persona p").getResultList();
return listaPersona;
}

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

}
